
<ul>
  <li class="dash1" style="margin-top:7px;">
    <a href="admin.php">
      <i class="glyphicon glyphicon-home"></i>
      <span class="option">Dashboard</span>
    </a>
  </li>
  <li class="dash1">
    <a href="users.php" class="submenu-toggle">
      <i class="glyphicon glyphicon-user"></i>
      <span>User Management</span>
    </a>
  </li>
  <li class="dash1">
    <a href="categorie.php" >
      <i class="glyphicon glyphicon-indent-left"></i>
      <span>Categories</span>
    </a>
  </li>
  <li class="dash1">
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-th-large"></i>
      <span>Products</span>
    </a>
    <ul class="nav submenu">
       <li class="dash2"><a href="product.php">Manage Products</a> </li>
       <li class="dash2"><a href="add_product.php">Add Products</a> </li>
   </ul>
  </li>
  <!-- <li class="dash1">
    <a href="stocks.php" >
      <i class="glyphicon glyphicon"></i>
      <span>Stocks</span>
    </a>
  </li> -->
  <li class="dash1">
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-stats"></i>
       <span>Stocks</span>
      </a>
      <ul class="nav submenu">
         <li class="dash2"><a href="stocks.php">Available Stocks</a> </li>
         <li class="dash2"><a href="restocks.php">Restock History</a> </li>
     </ul>
  </li>
  <li class="dash1">
    <a href="#" class="submenu-toggle">
      <i class="glyphicon glyphicon-credit-card"></i>
       <span>Sales</span>
      </a>
      <ul class="nav submenu">
         <li class="dash2"><a href="sales.php">Purchase History</a> </li>
         <li class="dash2"><a href="add_sale.php">POS</a> </li>
     </ul>
  </li>
</ul>
